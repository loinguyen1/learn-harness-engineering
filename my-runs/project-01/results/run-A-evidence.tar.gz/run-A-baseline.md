# Run A — Weak Harness (prompt only)

Date: 2026-08-29
Agent + model: Claude Code v2.1.81, headless `-p`
Prompt given (verbatim): "Build an Electron app that can show documents and answer questions."
Harness present: none in the run directory
Repo CLAUDE.md parked? (must be yes): **NO — see Validity below**

## VALIDITY: THIS RUN IS CONTAMINATED. DO NOT USE AS A BASELINE.

The repo-root `CLAUDE.md` was restored at 11:31:39 local; the run started
11:33:29. It was live and auto-loaded for the whole run. Fingerprint:

| Produced by the "baseline" agent | Stated in repo CLAUDE.md |
|---|---|
| `"dev": "node scripts/dev.js"` | "npm run dev  # Build + launch Electron (via scripts/dev.js)" |
| `check` / `test` / `test:watch` scripts | same three, verbatim |
| `tsconfig.json` + `tsconfig.node.json` | "Each project has two tsconfigs: tsconfig.json (renderer) and tsconfig.node.json (main/preload)" |
| `src/shared/types.ts` exporting `IPC_CHANNELS` | "IPC channels defined as constants in src/shared/types.ts (IPC_CHANNELS)" |
| DocumentService / IndexingService / QaService / PersistenceService | the same four, named |
| BrowserWindow 1200x800, contextIsolation true, nodeIntegration false | matches solution/feature_list.json evidence exactly |

A prompt-only agent does not invent `scripts/dev.js`. Re-run required.

## Timing
- Start: 04:33:29Z
- Agent declared done: 04:39:56Z (6m 27s)
- First successful launch: **never**
- Human interventions before launch: n/a — cannot launch

## Feature scoring
| # | Feature | Present? | Evidence observed |
|---|---|---|---|
| 1 | Window launches | **FAIL** | `npm run dev` dies in the build step; Electron never starts. Correct-looking `createWindow()` exists but never executes. |
| 2 | Document list panel + empty state | Code only | `DocumentList.tsx` written; cannot render — app won't build. |
| 3 | Question panel submitting over IPC | Code only | `QaPanel.tsx` + `IPC_CHANNELS.QA_ASK` wired; unverifiable. |
| 4 | Local data directory | Code only | `PersistenceService` does `fs.mkdirSync(dataDir, {recursive:true})` under `userData/kb-data`; never runs. |

**Verifiable features: 0 of 4.** All four written, none demonstrated.

## Build / test results (deps installed with an isolated npm cache)
- `npm run check` — 8 TypeScript errors
- `npm test` — 3 of 3 of the agent's OWN tests fail: `TypeError: indexing.index is not a function`
- `npm run dev` — build fails, `scripts/dev.js` throws, Electron never launches

Root cause, one bug, `src/services/IndexingService.ts`:
```ts
private index: Map<string, Chunk[]> = new Map()   // line 4 — field
index(doc: Document): Chunk[] { ... }              // line 6 — method, same name
```
The field clobbers the prototype method at construction. Every `indexingService.index(doc)`
throws at runtime — two IPC handlers plus app startup.

## Observations
- **Declared "The app is complete."** with no `node_modules` present. It never
  installed, never type-checked, never built, never launched. Textbook premature stop.
- It wrote its own unit tests and never ran them. All three fail on the same bug.
- Assumed unprompted: Electron+React+TypeScript+Vite+Vitest, a four-layer service
  split, IPC channel constants, chunked keyword-scored retrieval with citations.
  None of that was in the prompt — most of it came from the leaked CLAUDE.md.

## Artifacts
- Transcript: `results/run-A-transcript.log`
- Verification: `results/run-A-verify2.log`
- Launch attempt: `results/run-A-launch.log`
- Timing: `results/run-A-timing.txt`
